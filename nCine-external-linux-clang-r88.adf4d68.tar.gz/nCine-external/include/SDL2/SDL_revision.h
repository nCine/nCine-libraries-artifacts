/* #undef SDL_VENDOR_INFO */
#define SDL_REVISION_NUMBER 0

#ifdef SDL_VENDOR_INFO
#define SDL_REVISION "SDL-release-2.30.0-0-g859844eae (" SDL_VENDOR_INFO ")"
#else
#define SDL_REVISION "SDL-release-2.30.0-0-g859844eae"
#endif
